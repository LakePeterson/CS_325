Problem 4:

 * Must contain mergeSort.py, insertSort.py, and data.txt files.

 - Both the Merge and Insertion Sort programs were written in Python be sure to use python3 to execute these files.
 - Make sure that the data.txt file is contained within the same directory as the Merge and Insertion Sort files.
 - The .out file that is produced from the Merge and Insertion Sort programs will be created in the same directory.

 $ In order to execute these programs in the terminal it must be wrote like this: "python3 mergeSort" OR "python3 insertSort".




Problem 5:

 * Must contain mergeTime.py and insertTime.py files.

 - You will be prompted on the size of the array you would like to be sorted, in which that array will be filled with integers ranging from 0 - 10000.
 - ENTER ONLY INTEGERS PLEASE!
 - Both the Merge and Insertion Time programs were written in Python be sure to use python3 to execute these files.

 $ In order to execute these programs in the terminal it must be wrote like this: "python3 mergeTime" OR "python3 insertTime".
