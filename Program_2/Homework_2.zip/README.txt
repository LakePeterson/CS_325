Problem 5:

 * Must contain badSort.py, badSortTime.py, and data.txt.

 - Both the of the badSort programs were written in Python be sure to use python3 to execute these files.
 - In order for these algorithm programs to work NumPy must be installed on your machine, this can be done by typing "pip3 install numpy"
 - Make sure that the data.txt file is contained within the same directory as the badSort.py and badSortTime.py.
 - The bad.out file that is produced from the badSort.py program will be created in the same directory.
 - The badSortTime.py program will ask you for how many values you would like to sort and print out the time (seconds) it took to sort those values.
 - The alpha value can also be modified within the program at your discretion.

 $ In order to execute these programs in the terminal it must be wrote like this: "python3 badSort.py" OR "python3 badSortTime".
