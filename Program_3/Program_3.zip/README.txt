Problem 4d:

 * Must contain knapsack.py and data.txt.

 - The knapsack program was written in Python so be sure to use python3 to execute the file.
 - Make sure that the data.txt file is contained within the same directory as knapsack.py.
 - The data contained within must be formatted such that the weight is in the first row and the value is in the second row.

 $ In order to execute this program in the terminal it must be wrote like this: "python3 knapsack.py"
