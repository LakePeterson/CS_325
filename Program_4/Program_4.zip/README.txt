Problem 4:

 * Must contain change.py and data.txt.

 - The change program was written in Python so be sure to use python3 to execute the file.
 - Make sure that the data.txt file is contained within the same directory as change.py.
 - The data contained within must be formatted such that the it follows the format of the homework.

 $ In order to execute this program in the terminal it must be wrote like this: "python3 knapsack.py"
